#!/usr/bin/env python3

import publisher, configUWB, numpy, rospy
from serial import SerialException
import matplotlib.pyplot as plt

def acquisitionDIST(balise:str, nbPoints:int=1000):
    node = publisher.UwbXyzPublisher()
    node.connect()
    data = []

    for i in range(1, nbPoints):
        try:
            line = node.serial.readline().decode("ascii")
            node.parse_and_publish(line)
        except (ValueError, IndexError):
            rospy.loginfo("Error when parsing a frame from serial")
        except SerialException :
            rospy.logwarn("Device disconnection, retrying...")
            data = []
            i = 0
            node.connect()
        
        fb_cmd, fb_data = line.split(":",1)

        if fb_cmd == "+DIST": # Trame : +DIST:<t>,<anchor_id>,<dist>,<x>,<y>, ,<pwr>,<idiff>,<mc>
            fb_data.replace("\r\n","").replace(" ","0").split(",")
            anchor_id = fb_data[1]
            if anchor_id == balise:
                data.append( [ int(fb_data[0]), int(fb_data[2]) ] ) # t, dist

    return numpy.array(data)

def acquisitionTempsDIST(balise:str, totalTime:int=5000):
    node = publisher.UwbXyzPublisher()
    node.connect()
    data = []

    currentTime = 0
    try: buf = configUWB.sendCmd(node, "AT+TIME?")
    except (SyntaxError, SerialException):
        rospy.logerr("L'ancre UWB ne répond pas aux commandes AT, ")
        rospy.logerr(f"vérifiez que le noeud <{node}> est initialisé sur le bon port USB.\r\n")
        return -1
    
    endTime = int( buf.split(":")[-1] ) + totalTime

    while(currentTime < endTime):
        try:
            line = node.serial.readline().decode("ascii")
            node.parse_and_publish(line)
        except (ValueError, IndexError):
            rospy.loginfo("Error when parsing a frame from serial")
        except SerialException :
            rospy.logwarn("Device disconnection, retrying...")
            data = []
            i = 0
            node.connect()
        
        fb_cmd, fb_data = line.split(":",1)

        if fb_cmd == "+DIST": # Trame : +DIST:<t>,<anchor_id>,<dist>,<x>,<y>, ,<pwr>,<idiff>,<mc>
            fb_data.replace("\r\n","").replace(" ","0").split(",")
            anchor_id = fb_data[1]
            if anchor_id == balise:
                data.append( [ int(fb_data[0]), int(fb_data[2]) ] ) # t, dist

    return numpy.array(data)

def acquisition(nbPoints:int=1000, mode:str="MPOS"):
    node = publisher.UwbXyzPublisher()
    node.connect()
    data = []
    node.serial.reset_input_buffer()

    modesPossibles = ("MPOS", "DIST", "DUAL")
    if mode not in modesPossibles: 
        rospy.logerr(f"L'argument <mode> = {mode} doit être \"MPOS\", \"DIST\" ou \"DUAL\".\r\n")
        return
    if mode == "DUAL": traces = ("+MPOS", "+DIST")
    else : traces = (mode)

    for i in range(nbPoints) :
        try:
            line = node.serial.readline().decode("ascii")
        except SerialException:
            rospy.logwarn("Device disconnection, retrying...")
            data = []
            i = 0
            node.connect()
        except (ValueError, IndexError):
            rospy.logwarn("Error when parsing a frame from serial")
            pass
        
        fb_cmd = "0"
        try:
            fb_cmd, fb_data = line.split(":",1)
        except ValueError:
            pass

        if fb_cmd in traces: # Trame : +MPOS:<t>,<x>,<y>, ,<vx>,<vy>
            t,x,y,z,anchor,dist = -1
            if fb_cmd == "+MPOS":
                t,x,y,z = fb_data.replace("\r\n","").replace(" ","0").split(",")[0:4]
            elif fb_cmd == "DIST":
                fb_data.replace("\r\n","").replace(" ","0").split(",")
                anchor = fb_data[1]
                dist = fb_data[2]
            
            if (t != 0) :
                val = [int(t), int(x), int(y), int(z), str(anchor), int(dist)]
                data.append( val ) # t, x, y, z=0
    
    return numpy.array(data, int)


def acquisitionMPOS(nbPoints:int=1000):
    node = publisher.UwbXyzPublisher()
    node.connect()
    data = []
    node.serial.reset_input_buffer()

    for i in range(nbPoints) :
        try:
            line = node.serial.readline().decode("ascii")
        except SerialException:
            rospy.logwarn("Device disconnection, retrying...")
            data = []
            i = 0
            node.connect()
        except (ValueError, IndexError):
            rospy.logwarn("Error when parsing a frame from serial")
        
        fb_cmd = "0"
        try:
            fb_cmd, fb_data = line.split(":",1)
        except ValueError:
            pass

        if fb_cmd == "+MPOS": # Trame : +MPOS:<t>,<x>,<y>, ,<vx>,<vy>
            t,x,y,z = fb_data.replace("\r\n","").replace(" ","0").split(",")[0:4]
            if (t != 0) :
                val = [int(t), int(x), int(y), int(z)]
                data.append( val ) # t, x, y, z=0
    
    return numpy.array(data, int)

def acquisitionTempsMPOS(totalTime:float=5.0):
    node = publisher.UwbXyzPublisher()
    node.connect()
    data = []

    currentTime = 0
    node.serial.reset_input_buffer()
    
    try: buf = configUWB.sendCmd(node, "AT+TIME?")
    except (SyntaxError, SerialException):
        rospy.logerr("L'ancre UWB ne répond pas aux commandes AT, ")
        rospy.logerr(f"vérifiez que le noeud <{node}> est initialisé sur le bon port USB.\r\n")
        return -1
    
    endTime = int( buf.split(":")[-1] ) + int(totalTime*1000)

    while(currentTime < endTime):
        try:
            line = node.serial.readline().decode("ascii")
        except SerialException:
            rospy.logwarn("Device disconnection, retrying...")
            data = []
            i = 0
            node.connect()
        except (ValueError, IndexError):
            rospy.loginfo("Error when parsing a frame from serial")
            pass

        fb_cmd, fb_data = line.split(":",1)

        if fb_cmd == "+MPOS": # Trame : +MPOS:<t>,<x>,<y>, ,<vx>,<vy>
            t,x,y,z = fb_data.replace("\r\n","").replace(" ","0").split(",")[0:4]
            val = [int(t), int(x), int(y), int(z)]
            data.append( val ) # t, x, y, z=0
            #print(pos[-1])

    return numpy.array(data, int)

def analyseAcquisition(valeur:int=1000, samples:str="points", mode:str="MPOS"):
    
    samples = str(samples)
    mode = str(mode)
    dataPos = numpy.zeros((2,2))
    dataDist = numpy.zeros((2,2))

    if samples != "points" and samples != "temps":
        rospy.logerr("L'argument <samples> = <{samples}> doit être un string \"points\" ou \"temps\".\r\n")
        return -1
    if mode != "MPOS" and mode != "DIST":
        rospy.logerr("L'argument <mode> = <{mode}> doit être un string \"MPOS\", \"DIST\" ou \"DUAL\".\r\n")
        return -1

    try: 
        if mode == "MPOS": 
            if samples == "points" :  dataPos = acquisitionMPOS(valeur)
            elif samples == "temps" : dataPos = acquisitionTempsMPOS(valeur)
        elif mode == "DIST" : 
            if samples == "points" :  dataDist = acquisitionDIST("556509AF" , valeur)
            elif samples == "temps" : dataDist = acquisitionTempsDIST("556509AF", valeur)
        elif mode == "DUAL" :
            if samples == "points" : 
                dataPos  = acquisitionMPOS(valeur)
                dataDist = acquisitionDIST(valeur)
            elif samples == "temps" :
                dataPos  = acquisitionMPOS(valeur)
                dataDist = acquisitionDIST(valeur)
    except TypeError :
        rospy.logerr(f"L'argument <balise> doit être de type str.\r\n")
        return -1

    if numpy.shape(dataPos) == [2,2] and numpy.shape(dataDist) == [2,2]:
        return -1

    if numpy.shape(dataPos) != [2,2]:
        delta = []
        nbPoints, nbVar = dataPos.shape
        for i in range(nbPoints-1):    #Transformation des indices temporels en écarts temporels
            if (dataPos[i+1,0] - dataPos[i,0] < 99):
                delta.append(dataPos[i+1,0] - dataPos[i,0])
        delta = numpy.array(delta, int)
        moyennes = [ delta.mean() ]
        std = [ 3*delta.std() ]
        for var in range(nbVar-1) :
            moyennes.append(dataPos.mean(axis=0)[var+1])
            std.append(3*dataPos.std(axis=0)[var+1])

        if samples == "points": 
            print(f"\r\nValeurs moyennes pour une acquisition de {valeur} points:\r\n")
        else : 
            print(f"\r\nValeurs moyennes pour une acquisition de {valeur/1000:.3f} secondes:\r\n")

        print(f"x : {moyennes[1]:.2f} +/- {std[1]:.2f} cm\ny : {moyennes[2]:.2f} +/- {std[2]:.2f} cm\r\nz : {moyennes[3]} +/- ({std[3]:2f})")
        print(f"Temps d'échantillonnage moyen : {moyennes[0]:.2f} +/- {std[0]:.2f} ms")
        print(f"=> Fréquence d'échantillonnage moyenne : {1000/moyennes[0]:.2f} Hz\r\n")

    if numpy.shape(dataPos) != [2,2]:
        delta = []
        nbPoints, nbVar = dataDist.shape
        for i in range(nbPoints-1):    #Transformation des indices temporels en écarts temporels
            if (dataDist[i+1,0] - dataDist[i,0] < 99):
                delta.append(dataDist[i+1,0] - dataDist[i,0])
        delta = numpy.array(delta, int)
        moyennes = [ delta.mean() ]
        std = [ 3*delta.std() ]
        for var in range(nbVar-1) :
            moyennes.append(dataDist.mean(axis=0)[var+1])
            std.append(3*dataDist.std(axis=0)[var+1])

        if samples == "points": 
            print(f"\r\nValeurs moyennes pour une acquisition de {valeur} points:\r\n")
        else : 
            print(f"\r\nValeurs moyennes pour une acquisition de {valeur/1000:.3f} secondes:\r\n")

        print(f"x : {moyennes[1]:.2f} +/- {std[1]:.2f} cm\ny : {moyennes[2]:.2f} +/- {std[2]:.2f} cm\r\nz : {moyennes[3]} +/- ({std[3]:2f})")
        print(f"Temps d'échantillonnage moyen : {moyennes[0]:.2f} +/- {std[0]:.2f} ms")
        print(f"=> Fréquence d'échantillonnage moyenne : {1000/moyennes[0]:.2f} Hz\r\n")
    
    if mode == "DUAL":   return [dataPos, dataDist, moyennes, std, mode]
    elif mode == "DIST": return [dataDist, moyennes, std, mode]
    else: return [dataPos, moyennes, std, mode]


def afficheAnalyse( data:numpy.ndarray, moyennes:numpy.ndarray=None, std:numpy.ndarray=None,
                    mode:str="MPOS", balises:"list[str]"=() ):

    start = data[0,0]
    nbPoints, nbSubplots = data.shape   
    nbSubplots - 1

    if mode == "DIST" and len(balises) > 0:
        labels = (f"Distance à la balise {balises[i]} (cm)" for i in range(len(balises)))
    elif mode == "MPOS":
        labels = ("Coordonnée x (cm)", "Cordonnée y (cm)", "Hauteur z (cm)")
    else:
        rospy.logerr("Entrez une valeur correcte de <mode> (\"MPOS\" ou \"DIST\") et une liste <balises> d'au moins 4 éléments.\r\n")
        return -1
    
    if nbSubplots != 1 :
        fig, axes = plt.subplots(nbSubplots - 1, 1)
        #if mode == "MPOS": fig.title(f"{nbPoints:2d} relevés de position cartésienne sur la balise UWB")
        #elif mode == "DIST": fig.title(f"{nbPoints:2d} relevés de distance aux ancres UWB")
        
        for i in range(nbSubplots-1) :
            axes[i].set_xlim(left = 0, right = (data[:,0].max() - start)) 
            axes[i].set_xlabel("Temps (ms)")
            axes[i].grid()
            axes[i].set_ylim(bottom = moyennes[i+1] - 2*std[i+1] - 2, top = moyennes[i+1] + 2 + 2*std[i+1])
            #axes[i].set_ylim(bottom = -10 , top = 346)
            axes[i].set_yticks(numpy.arange(-10, 350,step =50))
            axes[i].set_ylabel(labels[i])
            x = data[:,0] - start
            y = data[:,i+1]
            axes[i].plot(x, y, 'b.', markersize = 2)
            if (moyennes != None and std != None):
                axes[i].text( axes[i].set_xlim()[1]*0.5, moyennes[i+1] + 1,  
                              f"Moyenne : {moyennes[i+1]:.2f} +/- {std[i+1]:.2f} cm")

    else :
        plt.figure()
        plt.title(f"{nbPoints:2d} relevés de distance sur la balise {balises[0]}")
        plt.grid()
        plt.xlabel("Time (ms)")
        plt.xlim(left = 0, right = (data[:,0].max() - start))
        plt.ylabel("Distance (cm)")
        #plt.yticks(numpy.arrange(-10, 350,step =10))
        plt.ylim(bottom = moyennes[1] - 2*std[1] - 1, top = moyennes[1] + 1 + 2*std[1])
        plt.plot(data[:,0], data[:,1], 'b.', markersize = 3)
        if (moyennes != None and std != None):
            plt.text( plt.xlim()[1]*0.5, plt.ylim()[1]*0.7, 
                      f"Moyenne : {moyennes[1]:.2f} +/- {std[1]:.2f} cm")

    plt.show()
    return 0

if __name__ == "__main__":
    [data, moy, std, mode] = analyseAcquisition(1000, "points", "DIST")
    afficheAnalyse(data, moy, std, mode)
