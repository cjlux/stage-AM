import publisher, numpy, rospy, serial
from acquisition import fetchMap
from math import dist
from scipy.optimize import minimize

def position(node:publisher.UwbXyzPublisher):

    mapUWB = fetchMap("mapUWB.json")
    if (mapUWB == None):
        return {"x": None, "y": None, "z": None, "mse": None}

    if (node.serial == None):
        rospy.logerr(f"Le noeud <{node}> n'a pas été initialisé avant l'appel.\n")
        node.connect()

    dist = [-1.0, -1.0, -1.0, -1.0]
    iter = 0
    while (iter < 10):
        dist = fetchDist(node, mapUWB)
        iter = iter + 1
    
    pos = trigonometrie(dist, mapUWB)

    return pos

def fetchDist(node:publisher.UwbXyzPublisher, mapUWB:numpy.ndarray):

    data = [-1.0, -1.0, -1.0, -1.0]
    for j in range( mapUWB.size/2 ):
        try:
            line = node.serial.readline().decode("ascii")
        except (ValueError, IndexError):
            rospy.loginfo("Error when parsing a frame from serial")
        except serial.serialutil.SerialException:
            rospy.logwarn("Device disconnection, retrying...")
            rospy.sleep(2)
            node.connect()
            
        #Parsing the line field into fb_cmd and fb_data fields
        fb = line.split(":")     
        if fb[0] == "+DIST_DBG":
            #Parsing the fb_data field into basic info
            fb_data = fb[1].replace("\r\n","").split(",") 
            anchor_id = fb_data[1]
            for i in range(4):
                if (mapUWB[i,0] == anchor_id):
                    data[i] = fb_data[2]
                    break

    if (-1.0 in data):
        rospy.logerr("Une ou plusieurs balises n'a pas transmis sa distance.")
    return data

def trigonometrie(dist:"list[float]", mapUWB:numpy.ndarray):
    
    locInit = numpy.array([ mapUWB[:,1].mean() , mapUWB[:,2].mean(), mapUWB[:,3].mean() ])
    locations = mapUWB[:, 1:3]

    #Algorithme pas à pas pour déterminer la solution optimale de x,y,z

    # initial_location: (x, y, z)
    # locations: [ (x1, y1, z1), ... ]
    # distances: [ distance1, ... ] 
    result = minimize(
        mse,                         # The error function
        locInit,                     # The initial guess
        args=(locations, dist),      # Additional parameters for mse
        method='L-BFGS-B',           # The optimisation algorithm
        options={
            'ftol':1e-5,         # Tolerance
            'maxiter': 1e+2      # Maximum iterations
        })

    pos = result.x
    return pos

# Mean Square Error
# locations: [ (lat1, long1), ... ]
# distances: [ distance1, ... ]
def mse(x, locations, distances):
    mse = 0.0
    for location, distance in zip(locations, distances):
        distanceRec = dist(x, location)
        mse += pow(distanceRec - distance, 2.0)
    return mse / len(distances)


def fetchMap( filepath:str ):
    if ( not filepath.endswith(".json") ):
        rospy.logerr(f"Le fichier {filepath} doit être de type .json\n")
        return None
    try:
        file = open(filepath, 'r')
    except (ValueError, PermissionError, FileNotFoundError):
        rospy.logerr(f"Le fichier {filepath} n'existe pas ou n'est pas n'est pas lisible\n")
        return None

    mapUWB = []
    entete = "NODE {" + "\n"

    for line in file:

        if line.startswith(entete):
            balise = file.readline().replace("\r\n","").split("=")[-1] 
            x = file.readline().replace("\r\n","").split("=")[-1] 
            y = file.readline().replace("\r\n","").split("=")[-1] 
            z = file.readline().replace("\r\n","").split("=")[-1] 
            mapUWB.append( [str( balise ), float( x ), float( y ), float( z )] )
    
    file.close()
    return numpy.array(mapUWB)


if __name__ == "__main__":
    #testDist = [5.0, 5.0, 5.0, 5.0]
    #testMap = numpy.array ([ ["1",  0,  0], ["2", 10,  0], ["3",  0, 10], ["4", 10, 10] ])
    node = publisher.UwbXyzPublisher.connect()
    pos = position(node)