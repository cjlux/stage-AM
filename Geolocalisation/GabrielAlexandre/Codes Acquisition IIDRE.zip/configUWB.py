#!/usr/bin/env python3
import rospy
from time import sleep
from serial import SerialException
from publisher import UwbXyzPublisher

inputSampleTime = 0.030

reponsesNonSoliscitees = {"DIST_DBG", "DIST", "MPOS" , "POS_INFO", "MESH", "VDD" , "MACC",
                          "MGYRO"   , "MGVT", "MQUAT", "MHRP"    , "DPOS", "DIMU", "DVDD"}

def sendCmd(node:UwbXyzPublisher, cmd):
    '''Ecrit une commande `cmd` quelconque sur la liaison série établie avec le noeud `node`.\n
    Renvoie la réponse de `node`, ou renvoie -1 si la réponse contient le string `ERREUR`.\n
    La réponse est un string décodé de l'ASCII dont les caractères de saut de ligne (\\r et \\n) sont retirés. 
    Si la liaison UART est fermée (suite à une commande RESET, etc.), une reconnexion est tentée sur le même port,
    et la fonction renvoie -1 en cas d'échec.'''

    cmd = str(cmd) 
    buf = bytes(cmd.replace("\r","").replace("\n","") + "\n", "ascii")

    if not node.serial.is_open :
        sleep(0.5)
        try :
            node.serial.timeout = 0
            node.serial.open()
        except SerialException : 
            rospy.logerr(f"La laison série avec le port <{node.device_port}> n'a pas pu être rétablie.\r\n")
            raise SerialException
    
    node.serial.reset_input_buffer()
    node.serial.write(buf)
    sleep(inputSampleTime)

    inputBytes = node.serial.inWaiting()
    lines:list[str] = []
    while (inputBytes > 0) :
        lines += node.serial.readline().decode("ascii")
        inputBytes -= len(lines[-1])

    arg = cmd.strip("AT").replace("\r\n","").strip().split("=")[0].lower()
    reponse = cmd

    for line in lines :
        if line.strip("+").split(":")[0] not in reponsesNonSoliscitees:
            if "OK" in line :
                if "?" not in arg : return cmd
                else : return reponse
            elif "ERROR" in line :
                if cmd == reponse : rospy.logerr(f"La commande {cmd} n'est pas reconnue.\r\n")
                else : rospy.logerr(f"La commande {cmd} a renvoyé un message d'erreur : \"{temp}\"\r\n")
                return -1
            else : temp = reponse
    
    if reponse == cmd : 
        rospy.logwarn(f"La commande {cmd} n'a pas généré de réponse.\r\n")
    return reponse

def configBalise(node:UwbXyzPublisher, filepath=None):
    '''Renvoie la configuration actuelle de la balise UWB rattachée au noeud `node`.\n
    En cas d'erreur d'ouverture, d'écriture ou de syntaxe, renvoie -1.\n
    Si `filepath` est laissé à None, alors la configuration de la balise reste inchangée.\n
    L'argument `filepath` doit pointer vers un fichier de configuration contenant des commandes AT.
    Ces commandes seront alors envoyées au noeud `node` afin de configurer la balise UWB.'''

    #assert type(filepath) is , rospy.logerr(f"L'argument <filepath> = <{filepath}> doit être de type str.\r\n")

    try: sendCmd(node, "AT")
    except (SyntaxError, SerialException):
        rospy.logerr(f"Vérifiez que le noeud <{node.device_name}> est initialisé sur le bon port USB.\r\n")
        return -1
    except (AssertionError, TimeoutError): return -1

    if filepath is not None:
        try: file = open(filepath, 'rt')
        except (OSError, FileNotFoundError):
            rospy.logerr(f"Le fichier <{filepath}> n'existe pas ou n'est pas n'est pas lisible.\r\n")
            return -1
        except TypeError:
            rospy.logerr(f"L'argument <filepath> = <{filepath}> doit être de type str.\r\n")
            return -1

        for line in file:
            if line.upper().startswith("AT+") :

                try: sendCmd(node, line.split(None,1)[0])
                except SyntaxError: 
                    rospy.logerr(f"La syntaxe de la commande <{line}> est incorrecte, corrigez le fichier de configuration {filepath}.\r\n")
                    return -1
                except SerialException:
                    rospy.logerr(f"La liaison série avec le port <{node.device_port}> n'a pas pu être établie.\r\n")
                    return -1
                print(f"L'ancre UWB a été configurée selon le fichier de commandes {filepath}.\r\n")
    
        file.close()

    if (sendCmd(node, "AT+RESET=0") != -1):
        node.serial.close()
        sleep(1)
    else : return -1

    node.connect()
    buf = sendCmd(node, "AT+CFG?")
    if (buf == -1) : return -1
    else : return buf

if __name__ == "__main__":

    node = UwbXyzPublisher()
    node.connect()
    #cfg = configBalise(node)
    cfg = sendCmd(node, "AT+CFG?")
    print(f"Configuration actuelle : {cfg}")